﻿// Serbian
plupload.addI18n({
    'Select files' : 'Izaberite fajlove',
    'Add files to the upload queue and click the start button.' : 'Dodajte fajlove u listu i kliknite na dugme Start.',
    'Filename' : 'Naziv fajla',
    'Status' : 'Status',
    'Size' : 'Veličina',
    'Add Files' : 'Dodaj fajlove',
    'Stop current upload' : 'Zaustavi upload',
    'Start uploading queue' : 'Počni upload',
    'Drag files here.' : 'Prevucite fajlove ovde.',
    'Start Upload': 'Počni upload',
    'Uploaded %d/%d files': 'Snimljeno %d/%d fajlova'
});